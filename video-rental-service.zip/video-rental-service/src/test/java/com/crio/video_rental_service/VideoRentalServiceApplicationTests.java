package com.crio.video_rental_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoRentalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
