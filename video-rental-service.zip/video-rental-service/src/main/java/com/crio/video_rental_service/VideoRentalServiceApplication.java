package com.crio.video_rental_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideoRentalServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideoRentalServiceApplication.class, args);
	}

}
